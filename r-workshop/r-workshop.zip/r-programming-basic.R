## Script 창으로 들어가는 키 숏컷: Ctrl + 1
## Console 창 들어가는 키 숏컷: Ctrl + 2
## Script 여러개일 때 다음 Script 고르기: Ctrl + Tab
## Script 여러개일 때 이전 Script 고르기: Ctrl + Shift + Tab
## Console 클리닝: Ctrl + L
## 메모리상의 모든 변수 및 데이터 삭제: rm(list = ls())
## R version check: Sys.getenv("R_ARCH") - 32 bit인 분은 R을 다시 인스톨해주시기 바랍니다
## 64 bit for "/x64"
## 32 bit for "/i386"
## 각 라인마다 Ctrl(Cmd) + Enter
# 맥에서 한글 깨질때
# Sys.setlocale(category = "LC_CTYPE", locale = "ko_KR.UTF-8")
# theme_set(theme_gray(base_family="AppleGothic"))
# par(family = "AppleGothic")


#######################################################
####### Part 1. Basic ########

####### 기본 사칙 연산 #######


####### 변수 선언 #######



####### 논리연산 #######


####### 비교연산 #######




####### 문자열 #######

# "Hello "Mr.Stranger"!"

# 문자열 길이


# 문자열 합치기 


# 문자열 일부 추출


# 문자열 나누기


# 포맷팅


####### Vector #######


# 다양한 벡터 선언


# 벡터값 접근



# 벡터 제외



# 벡터값 수정

# 벡터 합치기 및 추가



####### Condition (if-else) #######


# TODO: 1~10 사이에서 3 또는 5의 배수인 숫자를 출력하시오.

# TODO: 1~10 사이에서 3 또는 5의 배수인 숫자의 합을 구하시오. (답: 23)



####### for문 #######



####### 함수 #######




# TODO: 10보다 작은 자연수 중에서 3 또는 5의 배수는 3, 5, 6, 9 이고, 이것을 모두 더하면 23입니다.
# 1000보다 작은 자연수 중에서 3 또는 5의 배수를 모두 더하면 얼마일까요?




# TODO: 위에서 구현한 함수를 n 보다 작은 자연수 중에서 a 또는 b의 배수를 모두 더한 결과값을 반환해주는 함수로 만들어보시오.


